//: A UIKit based Playground for presenting user interface

// CREATED BY - YUGANTAR JAIN

/*
 GREETINGS,
 THIS PLAYGROUND IS ABOUT A DASHBOARD AND HOW IT CAN BE IMPLEMENTED FOR A SMALL SCREEN SUCH AS THAT OF AN IPHONE.
    IT DRAWS INSPIRATION FROM THE MACOS DASHBOARD.
    A FEW NON FUNCTIONAL UI SLIDERS HAVE BEEN INCLUDED FOR DEMONSTRATION OF HOW AN AMALGAMATION OF SUCH A DASHBOARD AND THE CONTROL CENTRE CAN CREATE SOMETHING EXTREMELY POWERFUL.
 
    *STICKY NOTES - They provide the fastest way for note making and will be the fastest way to jot down notes by implementing in the control centre.
    *IMAGE VIEW - It is mainly provided to add any important image that a person may need to refer to repeatedly. It may be an information based image or maybe of a person you just want to look at for an entire day.
 
 ****           WWDC'18 SUBMISSION      ****
 
 ****           DASHBOARD               ****
 
 */

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
     let defaultImage = UIImage(named: "DefaultImage.jpg")
     let noteImage = UIImage(named: "sticky.png")
     var currentY  = CGFloat(0.0)
     var currentX = CGFloat(5.0)
    
     let mainView = UIView()
     let scrollView = UIScrollView(frame: CGRect(x: 0, y: 68, width: 375, height: 600))
     let secondView = UIView(frame: CGRect(x: 0, y: 2, width: 375, height: 1200))
    
     var frame = CGRect(x: 0, y: 0, width: 180, height: 180)
    
    let option1 = UIButton(frame: CGRect(x: 63, y: 68, width: 250, height: 250))
    let option2 = UIButton(frame: CGRect(x: 63, y: 350, width: 250, height: 250))
    
    
     @objc func addView(sender: UIButton!)
     {
     scrollView.removeFromSuperview()
     mainView.addSubview(option1)
     mainView.addSubview(option2)
     self.view = mainView
     }
    
     @objc func addSticky(sender: UIButton!)
     {
     frame.origin.x = currentX
     frame.origin.y = currentY
     if(currentX==5)
     {
     currentX = 190
     }
     else
     {
     currentX = 5
     }
     if(currentX == 5)
     {
     currentY = currentY + 180 + 30
     }
    
     let sticky = UIButton(frame: frame)
     let stickyText = "Default Sticky Text. Change it in the editor to get the desired personalised text" // change to get a different sticky text
     sticky.setBackgroundImage(noteImage, for: .normal)
     sticky.layer.shadowRadius = 10
     sticky.layer.shadowColor = UIColor.darkGray.cgColor
     sticky.layer.shadowOpacity = 0.7
     sticky.setTitle(stickyText, for: .normal)
     sticky.titleLabel?.textAlignment = .center
     sticky.setTitleColor(.black, for: .normal)
     sticky.titleEdgeInsets = UIEdgeInsets(top: -5.0, left: 10.0, bottom: 5.0, right: 10.0)
     sticky.titleLabel?.lineBreakMode = .byWordWrapping
     sticky.titleLabel?.numberOfLines = 7
        option1.removeFromSuperview()
        option2.removeFromSuperview()
        secondView.addSubview(sticky)
        secondView.removeFromSuperview()
        scrollView.addSubview(secondView)
        mainView.addSubview(scrollView)
        self.view = mainView
     }
    @objc func addImage()
    {
        frame.origin.x = currentX
        frame.origin.y = currentY
        if(currentX==5)
        {
            currentX = 190
        }
        else
        {
            currentX = 5
        }
        if(currentX == 5)
        {
            currentY = currentY + 180 + 30
        }
        let imageView = UIImageView(frame: frame)
        imageView.layer.cornerRadius = 10
        imageView.layer.masksToBounds = true
        imageView.image = defaultImage
        option1.removeFromSuperview()
        option2.removeFromSuperview()
        secondView.addSubview(imageView)
        secondView.removeFromSuperview()
        scrollView.addSubview(secondView)
        mainView.addSubview(scrollView)
        self.view = mainView
    }
    
    override func loadView() {
        mainView.backgroundColor = .white
        
        option1.setBackgroundImage(noteImage, for: .normal)
        option2.setBackgroundImage(defaultImage, for: .normal)
        option1.addTarget(self, action: #selector(addSticky), for: .touchUpInside)
        option2.addTarget(self, action: #selector(addImage), for: .touchUpInside)
        
        secondView.backgroundColor = .white
        
        scrollView.contentSize = secondView.frame.size
        scrollView.backgroundColor = .gray
        
        let label = UILabel()
        label.frame = CGRect(x: 0, y: 0, width: 375, height: 68)
        label.backgroundColor = .black
        label.text = "DASHBOARD"
        label.textColor = .gray
        label.font = UIFont.systemFont(ofSize: 20.0)
        
        let addButton = UIButton(frame: CGRect(x:375-68, y:0, width:68, height:68))
        addButton.setTitle("+", for: .normal)
        addButton.setTitleColor(.black, for: .normal)
        addButton.backgroundColor = .gray
        addButton.titleLabel?.font = UIFont.systemFont(ofSize: 30.0)
        addButton.addTarget(self, action: #selector(addView), for: .touchUpInside)
        
        
        
//------------------------------DATE AND TIME-----------------------------
        let DateAndTime = UIButton(frame: CGRect(x: 0, y: currentY, width: 375, height: 90))
        let date = Date()
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: date)
        let year = components.year ?? 0
        let month = components.month ?? 0
        let day = components.day ?? 0
        let hour = components.hour ?? 0
        let minute = components.minute ?? 0
        let dateAndTimeString = "\(day)/\(month)/\(year) ,\t\(hour):\(minute)"
        let background = UIImage(named: "background.jpg")
        DateAndTime.setBackgroundImage(background, for: .normal)
        //DateAndTime.layer.cornerRadius = 10
        DateAndTime.layer.masksToBounds = true
        DateAndTime.setTitle(dateAndTimeString, for: .normal)
        DateAndTime.titleLabel?.lineBreakMode = .byWordWrapping
        //note2.titleLabel?.lineBreakMode = .byWordWrapping
        DateAndTime.titleLabel?.numberOfLines = 2
        DateAndTime.titleLabel?.font = UIFont.systemFont(ofSize: 35.0)
        DateAndTime.layer.shadowRadius = 30
        DateAndTime.layer.shadowColor = UIColor.darkGray.cgColor
        DateAndTime.layer.shadowOpacity = 0.7
        //DateAndTime.titleLabel?.adjustsFontSizeToFitWidth = true
        currentY = currentY + 90 + 30
        
//------------------------------------STICKY NOTE-----------------------------------
        
        let testlabel = "1.It's a sticky note\n2.Supports upto 7 lines\n3.Alter 'testLabel' to change its text."
        
        let note = UIButton(frame: CGRect(x: 5, y: currentY, width: 180, height: 180))
        note.setBackgroundImage(noteImage, for: .normal)
        //note.layer.cornerRadius = 7
        note.layer.shadowRadius = 10
        note.layer.shadowColor = UIColor.darkGray.cgColor
        note.layer.shadowOpacity = 0.7
        note.setTitle(testlabel, for: .normal)
        note.titleLabel?.textAlignment = .center
        note.setTitleColor(.black, for: .normal)
        note.titleEdgeInsets = UIEdgeInsets(top: -5.0, left: 10.0, bottom: 5.0, right: 10.0)
        note.titleLabel?.lineBreakMode = .byWordWrapping
        note.titleLabel?.numberOfLines = 7
        
//--------------------------------------IMAGE VIEW------------------------------------------
        let testImage = UIImageView(frame: CGRect(x: 190, y: currentY, width: 180, height: 180))
        testImage.layer.cornerRadius = 10
        testImage.layer.masksToBounds = true
        testImage.image = defaultImage
        currentY = currentY + 180 + 30
        
//----------------------------------INACTIVE UI(FOR DEMONSTRATION)-------------------------
        
        let slider1 = UISlider(frame: CGRect(x: 30, y: currentY, width: 375-60, height: 25))
        slider1.isEnabled = false
        currentY = currentY + 25 + 30
        let slider2 = UISlider(frame: CGRect(x: 30, y: currentY, width: 375-60, height: 25))
        slider2.isEnabled = false
        currentY = currentY + 25 + 30
        
        
        mainView.addSubview(label)
        mainView.addSubview(addButton)
        mainView.addSubview(scrollView)
        scrollView.addSubview(secondView)
        secondView.addSubview(DateAndTime)
        secondView.addSubview(note)
        secondView.addSubview(testImage)
        secondView.addSubview(slider1)
        secondView.addSubview(slider2)
        self.view = mainView
        
    }
}

PlaygroundPage.current.liveView = MyViewController()

